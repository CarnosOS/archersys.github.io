// check for retina - NOT IN USE
// if (window.devicePixelRatio > 1){
//   $("img.retina-ready").each(function(i, img){
//     // images/thing.png -> images/thing-retina.png
//     img.src = img.src.split(".").join("-retina.");
//   });
// }